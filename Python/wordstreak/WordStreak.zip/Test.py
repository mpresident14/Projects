if x1 == self.data[0][0] or x2 == self.data[0][0]:
            self.data[0][0] = termcolor.colored(self.data[0][0], 'blue')
            doubleLetterPos = [0,0]
        elif x1 == self.data[1][0] or x2 == self.data[1][0]:
            self.data[1][0] = termcolor.colored(self.data[1][0], 'blue')
            doubleLetterPos = [1,0]
        elif x1 == self.data[2][0] or x2 == self.data[2][0]:
            self.data[2][0] = termcolor.colored(self.data[2][0], 'blue')
            doubleLetterPos = [2,0]
        elif x1 == self.data[3][0] or x2 == self.data[3][0]:
            self.data[3][0] = termcolor.colored(self.data[3][0], 'blue')
            doubleLetterPos = [3,0]
        elif x1 == self.data[0][1] or x2 == self.data[0][1]:
            self.data[0][1] = termcolor.colored(self.data[0][1], 'blue')
            doubleLetterPos = [0,1]
        elif x1 == self.data[1][1] or x2 == self.data[1][1]:
            self.data[1][1] = termcolor.colored(self.data[1][1], 'blue')
            doubleLetterPos = [1,1]
        elif x1 == self.data[2][1] or x2 == self.data[2][1]:
            self.data[2][1] = termcolor.colored(self.data[2][1], 'blue')
            doubleLetterPos = [2,1]
        elif x1 == self.data[3][1] or x2 == self.data[3][1]:
            self.data[3][1] = termcolor.colored(self.data[3][1], 'blue')
            doubleLetterPos = [3,1]
        elif x1 == self.data[0][2] or x2 == self.data[0][2]:
            self.data[0][2] = termcolor.colored(self.data[0][2], 'blue')
            doubleLetterPos = [0,2]
        elif x1 == self.data[1][2] or x2 == self.data[1][2]:
            self.data[1][2] = termcolor.colored(self.data[1][2], 'blue')
            doubleLetterPos = [1,2]
        elif x1 == self.data[2][2] or x2 == self.data[2][2]:
            self.data[2][2] = termcolor.colored(self.data[2][2], 'blue')
            doubleLetterPos = [2,2]
        elif x1 == self.data[3][2] or x2 == self.data[3][2]:
            self.data[3][2] = termcolor.colored(self.data[3][2], 'blue')
            doubleLetterPos = [3,2]
        elif x1 == self.data[0][3] or x2 == self.data[0][3]:
            self.data[0][3] = termcolor.colored(self.data[0][3], 'blue')
            doubleLetterPos = [0,3]
        elif x1 == self.data[1][3] or x2 == self.data[1][3]:
            self.data[1][3] = termcolor.colored(self.data[1][3], 'blue')
            doubleLetterPos = [1,3]
        elif x1 == self.data[2][3] or x2 == self.data[2][3]:
            self.data[2][3] = termcolor.colored(self.data[2][3], 'blue')
            doubleLetterPos = [2,3]
        elif x1 == self.data[3][3] or x2 == self.data[3][3]:
            self.data[3][3] = termcolor.colored(self.data[3][3], 'blue')
            doubleLetterPos = [3,3]